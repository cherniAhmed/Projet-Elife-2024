import { Component } from '@angular/core';

@Component({
  selector: 'app-bank-sang-dashboard',
  templateUrl: './bank-sang-dashboard.component.html',
  styleUrls: ['./bank-sang-dashboard.component.scss']
})
export class BankSangDashboardComponent {

}
