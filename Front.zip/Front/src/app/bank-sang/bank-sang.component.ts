import { Component } from '@angular/core';

@Component({
  selector: 'app-bank-sang',
  templateUrl: './bank-sang.component.html',
  styleUrls: ['./bank-sang.component.scss']
})
export class BankSangComponent {

}
