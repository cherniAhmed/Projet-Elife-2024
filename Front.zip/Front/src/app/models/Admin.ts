export interface Admin {
    id?: number;
    nom: string;
    prenom: string;
    cin: string;
    telephone: string;
  }
  