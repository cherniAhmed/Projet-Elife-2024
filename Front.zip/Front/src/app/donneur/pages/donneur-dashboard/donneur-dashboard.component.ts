import { Component } from '@angular/core';

@Component({
  selector: 'app-donneur-dashboard',
  templateUrl: './donneur-dashboard.component.html',
  styleUrls: ['./donneur-dashboard.component.scss']
})
export class DonneurDashboardComponent {
  // Component logic here
}
