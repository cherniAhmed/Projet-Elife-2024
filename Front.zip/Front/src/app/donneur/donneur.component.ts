import { Component } from '@angular/core';

@Component({
  selector: 'app-donneur',
  templateUrl: './donneur.component.html',
  styleUrls: ['./donneur.component.scss']
})
export class DonneurComponent {

}
