import { Component } from '@angular/core';

@Component({
  selector: 'app-pied-de-page',
  templateUrl: './pied-de-page.component.html',
  styleUrls: ['./pied-de-page.component.scss']
})
export class PiedDePageComponent {

}
