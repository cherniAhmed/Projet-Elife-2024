import { Component } from '@angular/core';

@Component({
  selector: 'app-acceuill',
  templateUrl: './acceuill.component.html',
  styleUrls: ['./acceuill.component.scss']
})
export class AcceuillComponent {

}
