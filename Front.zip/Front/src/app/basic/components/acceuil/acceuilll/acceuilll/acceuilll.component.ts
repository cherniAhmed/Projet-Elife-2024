import { Component } from '@angular/core';

@Component({
  selector: 'app-acceuilll',
  templateUrl: './acceuilll.component.html',
  styleUrls: ['./acceuilll.component.scss']
})
export class AcceuilllComponent {

}
