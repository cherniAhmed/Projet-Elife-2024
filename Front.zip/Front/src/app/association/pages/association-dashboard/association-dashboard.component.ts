import { Component } from '@angular/core';

@Component({
  selector: 'app-association-dashboard',
  templateUrl: './association-dashboard.component.html',
  styleUrls: ['./association-dashboard.component.scss']
})
export class AssociationDashboardComponent {

}
