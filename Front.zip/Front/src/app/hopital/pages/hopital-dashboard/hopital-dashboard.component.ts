import { Component } from '@angular/core';

@Component({
  selector: 'app-hopital-dashboard',
  templateUrl: './hopital-dashboard.component.html',
  styleUrls: ['./hopital-dashboard.component.scss']
})
export class HopitalDashboardComponent {

}
